import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from playwright.sync_api import sync_playwright

here = Path(__file__).parent
out = here / "stills"
out.mkdir(exist_ok=True)
times = [float(x) for x in sys.argv[1:]] or [0.3, 0.85, 1.25, 1.75, 2.35, 3.3, 4.3, 5.75, 6.5, 7.4, 8.2, 8.62, 9.4, 10.8, 11.6, 12.6, 13.2, 13.6, 14.2, 14.7, 15.6, 16.3, 17.3, 17.9, 18.9, 19.9, 20.5, 20.95, 21.8, 22.9, 23.7, 24.2, 24.8, 25.7]
ARGS = ["--use-angle=d3d11", "--enable-gpu-rasterization", "--ignore-gpu-blocklist"]
with sync_playwright() as p:
    b = p.chromium.launch(args=ARGS)
    pg = b.new_page(viewport={"width": 1920, "height": 1080}, device_scale_factor=1)
    pg.goto((here / "index.html").as_uri())
    print("fonts", pg.evaluate("window.ready()"))
    errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    shots = []
    for t in times:
        pg.evaluate("t => window.seek(t, t)", t)
        f = out / f"t{t:05.2f}.png"
        pg.screenshot(path=str(f))
        shots.append((t, f))
    print("errors", errs[:3])
    b.close()
cols = 4
w, h = 480, 270
rows = (len(shots) + cols - 1) // cols
sheet = Image.new("RGB", (cols * (w + 8) + 8, rows * (h + 36) + 8), (40, 40, 40))
dr = ImageDraw.Draw(sheet)
font = ImageFont.truetype(r"C:\Windows\Fonts\malgun.ttf", 22)
for i, (t, f) in enumerate(shots):
    r, c = divmod(i, cols)
    im = Image.open(f).convert("RGB").resize((w, h))
    x, y = 8 + c * (w + 8), 8 + r * (h + 36)
    sheet.paste(im, (x, y))
    dr.text((x + 4, y + h + 4), f"{t:.2f}s", fill=(255, 255, 255), font=font)
sheet.save(here / "stills_sheet.jpg", quality=85)
print("sheet", sheet.size)
