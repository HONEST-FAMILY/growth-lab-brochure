import json
import math
import sys
from pathlib import Path

here = Path(__file__).parent
root = here.parent.parent
sys.path.insert(0, str(root / "brochure3" / "cover_more"))
sys.path.insert(0, str(root / "eventkit"))
from maze import maze_svg  # noqa: E402
from content import CLIENTS  # noqa: E402

CELL, COLS, ROWS = 50, 30, 8
X0 = (1920 - COLS * CELL) / 2
Y0 = 520
walls, path_d, pts = maze_svg(X0, Y0, CELL, COLS, ROWS, 19, 6, 1)
PTS = [[round(x, 1), round(y, 1)] for x, y in pts]

chips = "".join(f'<div class="chip" id="cl{i}"><span>{c}</span></div>' for i, c in enumerate(CLIENTS))

HTML = r"""<!doctype html>
<html lang="ko"><head><meta charset="utf-8">
<title>어니스트패밀리 사업성장연구소 홍보 영상</title>
<style>
@font-face{font-family:P;font-weight:300;src:url(fonts/Pretendard-Light.woff2) format('woff2')}
@font-face{font-family:P;font-weight:500;src:url(fonts/Pretendard-Medium.woff2) format('woff2')}
@font-face{font-family:P;font-weight:600;src:url(fonts/Pretendard-SemiBold.woff2) format('woff2')}
@font-face{font-family:P;font-weight:700;src:url(fonts/Pretendard-Bold.woff2) format('woff2')}
@font-face{font-family:P;font-weight:800;src:url(fonts/Pretendard-ExtraBold.woff2) format('woff2')}
*{box-sizing:border-box;margin:0;padding:0}
html,body{width:1920px;height:1080px;overflow:hidden;background:#000}
body{font-family:P,sans-serif;word-break:keep-all;-webkit-font-smoothing:antialiased}
#stage{position:absolute;left:0;top:0;width:1920px;height:1080px;overflow:hidden;background:#f7f8fa}
.sc{position:absolute;left:0;top:0;width:1920px;height:1080px;overflow:hidden}
.cam{position:absolute;left:0;top:0;width:1920px;height:1080px;transform-origin:960px 540px}
#A{background:#f7f8fa;z-index:1}
#BC{background:#3182f6;z-index:2;visibility:hidden}
#D{background:#f7f8fa;z-index:3;visibility:hidden}
#E{background:#3182f6;z-index:4;visibility:hidden}
#FG{background:#f7f8fa;z-index:5;visibility:hidden}
.ln{position:absolute;overflow:hidden;white-space:nowrap;line-height:1.18;padding:0 .04em .1em 0}
.ln>span{display:block;transform:translateY(115%)}
.ink{color:#191f28}.wh{color:#fff}.bl{color:#3182f6}.lb{color:#cfe2ff}.gr{color:#6b7684}
#wm{position:absolute;left:0;top:0;height:200px;display:flex;align-items:center;font-weight:800;font-size:170px;letter-spacing:-.055em;color:#191f28;white-space:nowrap}
#wmLetters{display:inline-block;transform-origin:100% 60%}
#dot{position:absolute;border-radius:999px;background:#191f28}
#pillLabel{position:absolute;overflow:hidden;line-height:1.2;white-space:nowrap}
#pillLabel span{display:block;font-weight:800;font-size:62px;letter-spacing:-.04em;color:#fff;transform:translateY(115%)}
#cursor{position:absolute;left:0;top:0;width:44px;height:44px;z-index:50;transform-origin:4px 4px}
svg.full{position:absolute;left:0;top:0;width:1920px;height:1080px;overflow:visible}
.tag{position:absolute;padding:10px 22px;border-radius:14px;font-weight:800;font-size:32px;letter-spacing:-.03em;white-space:nowrap;transform-origin:50% 50%}
#qdot{position:absolute;width:30px;height:30px;border-radius:50%;background:#fff;margin:-15px 0 0 -15px}
.rail{position:absolute;display:flex;gap:6px;padding:8px;border-radius:999px;background:#fff;box-shadow:0 6px 24px rgba(25,31,40,.08);transform-origin:0 50%}
.rc{position:relative;z-index:1;padding:14px 30px;border-radius:999px;font-weight:800;font-size:34px;letter-spacing:-.03em;color:#191f28;transform-origin:50% 50%}
.rc i{font-style:normal;color:#3182f6;margin-right:10px}
.rc.on{color:#fff}.rc.on i{color:#d6e8ff}
#railHi{position:absolute;border-radius:999px;background:#3182f6;z-index:0}
.card{position:absolute;background:#fff;border-radius:40px;box-shadow:0 18px 50px rgba(25,31,40,.10)}
#c1 .lab{position:absolute;left:56px;top:48px;font-weight:700;font-size:34px;color:#6b7684;letter-spacing:-.03em;overflow:hidden;white-space:nowrap}
#c1 .lab span{display:block}
#big62{position:absolute;left:52px;top:92px;font-weight:300;font-size:190px;letter-spacing:-.05em;color:#e5484d;line-height:1}
#big62 small{font-size:96px;font-weight:500}
#bar{position:absolute;left:56px;right:56px;top:330px;height:52px;border-radius:26px;background:#3182f6;overflow:hidden}
#barFill{position:absolute;left:0;top:0;bottom:0;background:#e5484d}
#leg{position:absolute;left:56px;right:56px;top:398px;display:flex;justify-content:space-between;font-weight:700;font-size:28px;color:#4e5968}
.opt{position:absolute;display:flex;align-items:center;padding:0 48px;border-radius:32px;background:#fff;box-shadow:0 14px 40px rgba(25,31,40,.10);font-weight:800;font-size:46px;letter-spacing:-.04em;color:#191f28;transform-origin:50% 50%;overflow:hidden}
.opt .om{overflow:hidden;line-height:1.25;padding-bottom:.06em}
.opt span{display:block;white-space:nowrap}
#o3 b{margin-left:auto;width:58px;height:58px;border-radius:50%;background:#fff;color:#3182f6;display:flex;align-items:center;justify-content:center;font-size:36px}
#phone{position:absolute;background:#191f28;overflow:hidden}
#phone .scr{position:absolute;left:12px;top:12px;right:12px;bottom:12px;border-radius:44px;overflow:hidden;background:#191f28}
#phone .scr img{position:absolute;left:0;top:0;width:100%;height:100%;object-fit:cover;object-position:50% 0}
.ad{position:absolute;width:200px;height:250px;border-radius:24px;overflow:hidden;box-shadow:0 14px 34px rgba(25,31,40,.18);transform-origin:50% 50%}
.ad img{width:100%;height:100%;object-fit:cover;display:block}
.ad em{position:absolute;left:12px;bottom:12px;padding:6px 14px;border-radius:99px;background:#fff;font-style:normal;font-weight:800;font-size:22px;color:#3182f6}
#stat .num{position:absolute;left:56px;top:46px;font-weight:300;font-size:200px;letter-spacing:-.05em;color:#fff;line-height:1}
#stat .num small{font-size:100px;font-weight:500}
#stat .sl{position:absolute;left:62px;top:270px;font-weight:800;font-size:44px;color:#fff;letter-spacing:-.03em;overflow:hidden;white-space:nowrap}
#stat .sl span{display:block}
#stat .ss{position:absolute;left:62px;top:332px;font-weight:600;font-size:30px;color:#d6e8ff;letter-spacing:-.02em;overflow:hidden;white-space:nowrap}
#stat .ss span{display:block}
#bars{position:absolute;right:56px;bottom:50px;width:220px;height:150px;display:flex;align-items:flex-end;gap:12px}
#bars i{flex:1;background:rgba(255,255,255,.45);border-radius:10px 10px 4px 4px;transform-origin:50% 100%}
#bars i:last-child{background:#fff}
.chip{position:absolute;height:96px;padding:0 40px;border-radius:999px;background:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:40px;letter-spacing:-.04em;color:#191f28;white-space:nowrap;transform-origin:50% 50%}
#cta{position:absolute;height:104px;padding:0 48px;border-radius:999px;background:#3182f6;display:flex;align-items:center;font-weight:800;font-size:42px;color:#fff;letter-spacing:-.03em;white-space:nowrap;transform-origin:50% 50%}
#qr{position:absolute;width:236px;padding:20px 20px 14px;border-radius:28px;background:#fff;box-shadow:0 14px 40px rgba(25,31,40,.12);text-align:center;transform-origin:50% 50%}
#qr img{display:block;width:196px;height:196px}
#qr b{display:block;margin-top:10px;font-weight:800;font-size:24px;color:#191f28;letter-spacing:-.03em}
</style></head><body>
<div id="stage">
 <div class="sc" id="A"><div class="cam" id="camA">
  <div id="wm"><span id="wmLetters">honest family</span></div>
  <div id="dot"></div>
  <div id="pillLabel"><span>사업성장연구소</span></div>
 </div></div>
 <div class="sc" id="BC"><div class="cam" id="camBC">
  <div class="ln wh" id="q1" style="left:160px;top:250px;font-weight:800;font-size:132px;letter-spacing:-.05em"><span>매출 고민,</span></div>
  <div class="ln wh" id="q2" style="left:160px;top:410px;font-weight:800;font-size:132px;letter-spacing:-.05em"><span>뭐부터 해야 할지</span></div>
  <div class="ln lb" id="q3" style="left:160px;top:570px;font-weight:800;font-size:132px;letter-spacing:-.05em"><span id="q3s">막막하신가요?</span></div>
  <div class="ln wh" id="m1" style="left:160px;top:130px;font-weight:800;font-size:104px;letter-spacing:-.05em"><span>막연함을,</span></div>
  <div class="ln wh" id="m2" style="left:160px;top:262px;font-weight:800;font-size:104px;letter-spacing:-.05em"><span>다음 할 일로.</span></div>
  <svg class="full" viewBox="0 0 1920 1080" fill="none">
   <defs><clipPath id="wipe"><rect id="wipeR" x="0" y="0" width="0" height="1080"/></clipPath></defs>
   <path id="walls" clip-path="url(#wipe)" d="%%WALLS%%" stroke="#fff" stroke-opacity=".3" stroke-width="3.5" stroke-linecap="square"/>
   <path id="mpath" d="%%PATH%%" stroke="#fff" stroke-width="9" stroke-linejoin="round" stroke-linecap="round"/>
   <circle id="mhead" r="13" fill="#fff"/>
   <circle id="mring" r="30" stroke="#fff" stroke-width="3.5" stroke-opacity=".7"/>
  </svg>
  <div class="tag wh" id="tagA" style="background:#3182f6">막연함</div>
  <div class="tag" id="tagB" style="background:#fff;color:#3182f6">다음 할 일</div>
  <div id="qdot"></div>
 </div></div>
 <div class="sc" id="D"><div class="cam" id="camD">
  <div class="ln bl" id="dk" style="left:160px;top:96px;font-weight:800;font-size:44px;letter-spacing:-.03em"><span>사업성장연구소가 하는 일</span></div>
  <div class="rail" id="rail" style="left:160px;top:170px"><div id="railHi"></div><div class="rc" id="r0"><i>01</i>진단</div><div class="rc" id="r1"><i>02</i>결정</div><div class="rc" id="r2"><i>03</i>실행</div><div class="rc" id="r3"><i>04</i>확인</div></div>
  <div class="ln ink" id="s1a" style="left:160px;top:380px;font-weight:800;font-size:96px;letter-spacing:-.05em"><span>데이터로</span></div>
  <div class="ln ink" id="s1b" style="left:160px;top:500px;font-weight:800;font-size:96px;letter-spacing:-.05em"><span>원인을 찾고</span></div>
  <div class="ln gr" id="s1c" style="left:164px;top:650px;font-weight:600;font-size:36px;letter-spacing:-.03em"><span>광고로 들어온 신규 고객의 62%가 첫 구매 뒤 떠났습니다</span></div>
  <div class="ln ink" id="s2a" style="left:160px;top:380px;font-weight:800;font-size:96px;letter-spacing:-.05em"><span>가장 크게 걸린 일</span></div>
  <div class="ln ink" id="s2b" style="left:160px;top:500px;font-weight:800;font-size:96px;letter-spacing:-.05em"><span>하나를 정하고</span></div>
  <div class="ln gr" id="s2c" style="left:164px;top:650px;font-weight:600;font-size:36px;letter-spacing:-.03em"><span>떠나는 고객을 다시 오게 만들기로</span></div>
  <div class="ln ink" id="s3a" style="left:160px;top:380px;font-weight:800;font-size:96px;letter-spacing:-.05em"><span>만들고, 알리고,</span></div>
  <div class="ln bl" id="s3b" style="left:160px;top:500px;font-weight:800;font-size:96px;letter-spacing:-.05em"><span>광고까지 한 팀이</span></div>
  <div class="ln gr" id="s3c" style="left:164px;top:650px;font-weight:600;font-size:36px;letter-spacing:-.03em"><span>추천 메뉴 페이지 · 가설마다 다른 광고 소재</span></div>
  <div class="ln ink" id="s4a" style="left:160px;top:380px;font-weight:800;font-size:96px;letter-spacing:-.05em"><span>숫자로</span></div>
  <div class="ln ink" id="s4b" style="left:160px;top:500px;font-weight:800;font-size:96px;letter-spacing:-.05em"><span>확인합니다</span></div>
  <div class="ln gr" id="s4c" style="left:164px;top:650px;font-weight:600;font-size:36px;letter-spacing:-.03em"><span>123타이어 · 새 사이트 오픈 전후 1년 비교</span></div>
  <div class="card" id="c1"><div class="lab"><span>뽀뽀뜨 · 첫 구매 고객</span></div><div id="big62"><span id="n62">0</span><small>%</small></div><div id="bar"><div id="barFill"></div></div><div id="leg"><span>떠난 고객</span><span>다시 산 고객</span></div></div>
  <div class="opt" id="o1"><div class="om"><span>광고 더 하기</span></div></div>
  <div class="opt" id="o2"><div class="om"><span>새 메뉴 만들기</span></div></div>
  <div class="opt" id="o3"><div class="om"><span>다시 사게 만들기</span></div><b>✓</b></div>
  <div id="phone"><div class="scr"><img id="pimg" src="assets/real-pp-landing.jpg" alt=""></div></div>
  <div class="ad" id="adA"><img src="assets/pp-ad-babtae.jpg" alt=""><em>가설 A</em></div>
  <div class="ad" id="adB"><img src="assets/pp-ad-nutri.jpg" alt=""><em>가설 B</em></div>
  <div class="ad" id="adC"><img src="assets/pp-ad-review.jpg" alt=""><em>가설 C</em></div>
  <div class="card" id="stat" style="background:#3182f6"><div class="num"><span>+</span><span id="n246">0.0</span><small>%</small></div><div class="sl"><span>리뉴얼 후 1년 매출</span></div><div class="ss"><span>123타이어 · 주문 수 +22.2%</span></div><div id="bars"><i></i><i></i><i></i><i></i><i></i><i></i></div></div>
 </div></div>
 <div class="sc" id="E"><div class="cam" id="camE">
  <div class="ln wh" id="e1" style="left:0;width:1920px;text-align:center;top:150px;font-weight:800;font-size:92px;letter-spacing:-.05em"><span>다양한 규모의 업체와</span></div>
  <div class="ln wh" id="e2" style="left:0;width:1920px;text-align:center;top:268px;font-weight:800;font-size:92px;letter-spacing:-.05em"><span>협력해 왔습니다.</span></div>
  %%CHIPS%%
  <div id="edot" style="position:absolute;width:40px;height:40px;margin:-20px 0 0 -20px;border-radius:50%;background:#fff;left:960px;top:690px"></div>
 </div></div>
 <div class="sc" id="FG"><div class="cam" id="camFG">
  <div class="ln ink" id="f1" style="left:160px;top:300px;font-weight:800;font-size:136px;letter-spacing:-.055em"><span>만들고 끝내지 않는</span></div>
  <div class="ln bl" id="f2" style="left:160px;top:470px;font-weight:800;font-size:136px;letter-spacing:-.055em"><span>실행 파트너,</span></div>
  <div class="ln ink" id="f3" style="left:0;width:1920px;text-align:center;top:350px;font-weight:800;font-size:190px;letter-spacing:-.06em"><span>사업성장연구소</span></div>
  <div id="wm2" style="position:absolute;left:0;top:0;height:200px;display:flex;align-items:center;font-weight:800;font-size:150px;letter-spacing:-.055em;color:#191f28;white-space:nowrap"><span id="wm2Letters" style="display:inline-block;transform-origin:100% 60%">honest family</span></div>
  <div id="dot2" style="position:absolute;border-radius:999px;background:#3182f6"></div>
  <div class="ln gr" id="tg" style="left:0;width:1920px;text-align:center;top:560px;font-weight:700;font-size:52px;letter-spacing:-.04em"><span>매출 고민, 막막할 땐 <b style="color:#3182f6">사업성장연구소</b></span></div>
  <div id="cta">무료 사업 분석 · honest-family.com</div>
  <div id="qr"><img src="assets/qr-screen.svg" alt=""><b>QR로 신청</b></div>
 </div></div>
 <svg id="cursor" viewBox="0 0 44 44"><path d="M6 4 L6 34 L13.5 27 L18.5 39 L24 36.5 L19 25 L29 25 Z" fill="#191f28" stroke="#fff" stroke-width="2.6" stroke-linejoin="round"/></svg>
</div>
<script>
const PTS = %%PTS%%;
const N_CLIENTS = %%NCL%%;
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const seg=(t,a,b)=>clamp((t-a)/(b-a));
const lerp=(a,b,p)=>a+(b-a)*p;
const eo3=x=>1-Math.pow(1-x,3), eo4=x=>1-Math.pow(1-x,4), ei3=x=>x*x*x;
const eexp=x=>x>=1?1:1-Math.pow(2,-10*x);
const eio3=x=>x<.5?4*x*x*x:1-Math.pow(-2*x+2,3)/2;
const glide=x=>{const p=clamp(x);return p<.5?4*p*p*p:1-Math.pow(-2*p+2,3)/2;};
function spring(t,t0,f=2.3,z=0.62){if(t<=t0)return 0;const w=2*Math.PI*f,wd=w*Math.sqrt(1-z*z),x=t-t0;return 1-Math.exp(-z*w*x)*(Math.cos(wd*x)+z*w/wd*Math.sin(wd*x));}
const $=id=>document.getElementById(id);
const W=1920,H=1080,MAXR=Math.hypot(W,H);
function rise(id,t,tin,tout=99,dur=0.5){const sp=$(id).firstElementChild;const pi=eexp(seg(t,tin,tin+dur));const po=eio3(seg(t,tout,tout+0.32));sp.style.transform=`translateY(${((1-pi)*115-po*115).toFixed(2)}%)`;}
function reveal(id,t,t0,x,y,dur=0.35){const el=$(id);const p=seg(t,t0,t0+dur);if(p<=0){el.style.visibility='hidden';return 0;}el.style.visibility='visible';const far=Math.max(Math.hypot(x,y),Math.hypot(W-x,y),Math.hypot(x,H-y),Math.hypot(W-x,H-y))*1.03;const e=p*p;const r=Math.sqrt(e)*far;el.style.clipPath=p>=1?'none':`circle(${r.toFixed(1)}px at ${x}px ${y}px)`;return p;}
function hideIfCovered(id,t,t1){$(id).style.display=t>=t1?'none':'block';}
function pop(el,t,t0,from=0){const s=t<t0?from:lerp(from,1,spring(t,t0));return s;}
function cam(id,t,keys){let z=1,x=0,y=0;for(let i=0;i<keys.length-1;i++){const[a,za,xa,ya]=keys[i],[b,zb,xb,yb]=keys[i+1];if(t>=a&&t<=b){const p=glide(seg(t,a,b));z=Math.exp(lerp(Math.log(za),Math.log(zb),p));x=lerp(xa,xb,p);y=lerp(ya,yb,p);break;}if(t>b){z=zb;x=xb;y=yb;}}$(id).style.transform=`translate(${x}px,${y}px) scale(${z})`;}
let L=[],TOTAL=0,WM={},WM2={};
function measure(){
  for(let i=0;i<PTS.length-1;i++){const d=Math.hypot(PTS[i+1][0]-PTS[i][0],PTS[i+1][1]-PTS[i][1]);L.push(d);TOTAL+=d;}
  const mp=$('mpath');mp.style.strokeDasharray=TOTAL;
  const wm=$('wm');wm.style.left='0px';const r=wm.getBoundingClientRect();WM.w=r.width;
  const wm2=$('wm2');const r2=wm2.getBoundingClientRect();WM2.w=r2.width;
  const q3l=$('q3').getBoundingClientRect();WM.q3x=q3l.left+$('q3s').offsetWidth+26;WM.q3y=q3l.top+q3l.height*0.56;
}
function pathAt(f){let d=f*TOTAL;for(let i=0;i<L.length;i++){if(d<=L[i]){const p=L[i]?d/L[i]:0;return[lerp(PTS[i][0],PTS[i+1][0],p),lerp(PTS[i][1],PTS[i+1][1],p)];}d-=L[i];}return PTS[PTS.length-1];}
function placeChips(){const rows=[[0,1,2,3],[4,5,6,7],[8,9,10]];const out=[];rows.forEach((row,ri)=>{const ws=row.map(i=>$('cl'+i).getBoundingClientRect().width);const gap=22;const tw=ws.reduce((a,b)=>a+b,0)+gap*(row.length-1);let x=(W-tw)/2;row.forEach((i,k)=>{out[i]=[x,450+ri*124,ws[k]];x+=ws[k]+gap;});});return out;}
let CH=null;
function cursorAt(t){
  const c=$('cursor');let x=-100,y=-100,s=1,vis=false;
  const seq=[[1.55,2.0,[1500,900],[1000,560]],[12.55,13.0,[1500,980],[1430,733]],[24.75,25.15,[1700,1000],[1240,745]]];
  for(const[a,b,p0,p1] of seq){if(t>=a&&t<b+ (a<20?0.45:9)){vis=true;const p=glide(seg(t,a,b));x=lerp(p0[0],p1[0],p);y=lerp(p0[1],p1[1],p);}}
  const clicks=[2.05,13.05];for(const k of clicks){if(t>=k&&t<k+0.35){s=1-0.16*Math.sin(Math.PI*seg(t,k,k+0.22));}}
  if(t>=2.5&&t<12.5)vis=false;if(t>=13.5&&t<24.75)vis=false;
  c.style.display=vis?'block':'none';c.style.transform=`translate(${x}px,${y}px) scale(${s})`;
}
window.seek=function(t,tf){
  if(tf===undefined)tf=t;
  // ---------- A: wordmark -> dot -> pill
  cam('camA',t,[[0,1,0,0],[2.2,1.06,0,0]]);
  const fs=170, dotS=34;
  const wmW=WM.w, wx=(W-wmW-dotS*0.9)/2, wy=440;
  const sq=ei3(seg(t,0.55,1.05));
  $('wm').style.left=wx+'px';$('wm').style.top=wy+'px';
  $('wmLetters').style.transform=`scaleX(${(1-sq*0.985).toFixed(4)})`;
  $('wmLetters').style.visibility=sq>=0.999?'hidden':'visible';
  const dotX0=wx+wmW+dotS*0.15, dotY0=wy+128;
  const g=glide(seg(t,1.0,1.5));
  const dw=lerp(dotS,600,g), dh=lerp(dotS,136,g);
  const sqShift=sq*(wmW*0.985);
  const cx0=dotX0+dotS/2-sqShift*0, cy0=dotY0+dotS/2;
  const cxA=lerp(cx0- (wmW*sq*0.0),960,g), cyA=lerp(cy0,540,g);
  const press=t>=2.05&&t<2.4?1-0.035*Math.sin(Math.PI*seg(t,2.05,2.3)):1;
  const dot=$('dot');dot.style.width=dw+'px';dot.style.height=dh+'px';dot.style.left=(cxA-dw/2)+'px';dot.style.top=(cyA-dh/2)+'px';
  const col=g;dot.style.background=`rgb(${Math.round(lerp(25,49,col))},${Math.round(lerp(31,130,col))},${Math.round(lerp(40,246,col))})`;
  dot.style.transform=`scale(${press})`;
  const lbl=$('pillLabel');lbl.style.left=(960-205)+'px';lbl.style.top=(540-38)+'px';
  rise('pillLabel',t,1.45,2.3,0.45);
  // ---------- BC
  reveal('BC',t,2.2,960,540,0.35);
  hideIfCovered('A',t,2.56);
  cam('camBC',t,[[2.2,1.0,0,0],[8.4,1.04,-24,0]]);
  rise('q1',t,2.85,5.35);rise('q2',t,3.25,5.42);rise('q3',t,3.65,5.49);
  const qd=$('qdot');
  const qp=spring(t,4.35);const mv=glide(seg(t,5.5,6.05));
  const qx=lerp(WM.q3x,PTS[0][0],mv), qy=lerp(WM.q3y,PTS[0][1],mv);
  qd.style.left=qx+'px';qd.style.top=qy+'px';qd.style.transform=`scale(${t<4.35?0:qp*(1-0.35*mv)})`;qd.style.display=t>=6.3?'none':'block';
  rise('m1',t,6.0);rise('m2',t,6.18);
  $('wipeR').setAttribute('width',(W*eo3(seg(t,5.9,6.6))).toFixed(1));
  const pf=eio3(seg(t,6.25,7.95));
  const mp=$('mpath');mp.style.strokeDashoffset=(TOTAL*(1-pf)).toFixed(1);mp.style.visibility=t>=6.25?'visible':'hidden';
  const hp=pathAt(pf);const mh=$('mhead');mh.setAttribute('cx',hp[0]);mh.setAttribute('cy',hp[1]);mh.style.visibility=t>=6.0?'visible':'hidden';
  const end=PTS[PTS.length-1];const mr=$('mring');mr.setAttribute('cx',end[0]);mr.setAttribute('cy',end[1]);const rr=spring(t,7.95);mr.setAttribute('r',(30*rr).toFixed(2));mr.style.visibility=t>=7.95?'visible':'hidden';
  const ta=$('tagA');ta.style.left=(PTS[0][0]-10)+'px';ta.style.top=(PTS[0][1]+34)+'px';ta.style.transform=`scale(${t<6.3?0:spring(t,6.3)})`;
  const tb=$('tagB');tb.style.left=(end[0]-212)+'px';tb.style.top=(end[1]-108)+'px';tb.style.transform=`scale(${t<7.95?0:spring(t,7.95)})`;
  // ---------- D
  reveal('D',t,8.45,end[0],end[1],0.35);
  hideIfCovered('BC',t,8.81);
  cam('camD',t,[[8.45,1.035,0,0],[9.6,1.0,0,0]]);
  rise('dk',t,8.95);
  const steps=[9.55,12.0,14.0,16.0];
  ['r0','r1','r2','r3'].forEach((id,i)=>{const el=$(id);el.style.transform=`scale(${t<9.05+i*0.12?0:spring(t,9.05+i*0.12)})`;});
  let ai=0;for(let i=0;i<4;i++)if(t>=steps[i]+0.12)ai=i;$('rail').style.transform=`scale(${t<8.98?0:spring(t,8.98,2.2,0.75)})`;
  const rcs=[0,1,2,3].map(i=>$('r'+i));
  const rails=$('rail').getBoundingClientRect();
  const boxes=rcs.map(e=>[e.offsetLeft,e.offsetWidth,e.offsetTop,e.offsetHeight]);
  let hx=boxes[0][0],hw=boxes[0][1];
  for(let i=1;i<4;i++){const p=glide(seg(t,steps[i]-0.05,steps[i]+0.3));hx=lerp(hx,boxes[i][0],p);hw=lerp(hw,boxes[i][1],p);}
  const hi=$('railHi');hi.style.left=hx+'px';hi.style.width=hw+'px';hi.style.top=boxes[0][2]+'px';hi.style.height=boxes[0][3]+'px';hi.style.transform=`scale(${t<steps[0]?0:spring(t,steps[0])})`;
  rcs.forEach((e,i)=>e.classList.toggle('on',i===ai&&t>=steps[0]+0.1));
  rise('s1a',t,9.7,11.7);rise('s1b',t,9.85,11.75);rise('s1c',t,10.1,11.8);
  rise('s2a',t,12.1,13.7);rise('s2b',t,12.25,13.75);rise('s2c',t,12.5,13.8);
  rise('s3a',t,14.1,15.7);rise('s3b',t,14.25,15.75);rise('s3c',t,14.5,15.8);
  rise('s4a',t,16.1,19);rise('s4b',t,16.25,19);rise('s4c',t,16.5,19);
  // card 1 (diagnosis) -> option 1
  const c1=$('c1');const c1p=t<9.75?0:spring(t,9.75,2.0,0.7);
  const mo=glide(seg(t,11.85,12.3));
  const c1w=lerp(720,640,mo),c1h=lerp(470,124,mo),c1x=lerp(1040,1080,mo),c1y=lerp(330,360,mo);
  c1.style.left=c1x+'px';c1.style.top=c1y+'px';c1.style.width=c1w+'px';c1.style.height=c1h+'px';c1.style.borderRadius=lerp(40,32,mo)+'px';
  c1.style.transform=`scale(${c1p})`;c1.style.display=(t>=12.3)?'none':'block';
  const inner=1-eio3(seg(t,11.7,11.95));
  c1.querySelectorAll('.lab,#big62,#bar,#leg').forEach(e=>{e.style.transform=`translateY(${((1-inner)*-30).toFixed(1)}px)`;e.style.clipPath=`inset(0 0 ${((1-inner)*100).toFixed(1)}% 0)`;});
  const n=Math.round(62*eo3(seg(tf,10.2,11.3)));$('n62').textContent=n;
  $('barFill').style.width=(62*eo3(seg(t,10.2,11.3)))+'%';
  // options
  const o1=$('o1'),o2=$('o2'),o3=$('o3');
  const oy=[360,512,664];
  [o1,o2,o3].forEach((o,i)=>{o.style.left='1080px';o.style.width='640px';o.style.height='124px';o.style.display=(t>=12.3&&t<14.45)?'flex':'none';});
  o1.style.top=oy[0]+'px';
  o2.style.top=lerp(oy[0],oy[1],t<12.25?0:spring(t,12.25,2.2,0.7))+'px';
  o3.style.top=lerp(oy[0],oy[2],t<12.35?0:spring(t,12.35,2.2,0.7))+'px';
  [o1,o2,o3].forEach((o,i)=>{const sp=o.querySelector('.om span');const p=eexp(seg(t,12.3+i*0.08,12.75+i*0.08));const q=i===2?eio3(seg(t,13.95,14.15)):0;sp.style.transform=`translateY(${((1-p)*120-q*120).toFixed(1)}%)`;});
  const sel=seg(t,13.05,13.3);
  o3.style.background=`rgb(${Math.round(lerp(255,49,sel))},${Math.round(lerp(255,130,sel))},${Math.round(lerp(255,246,sel))})`;
  o3.style.color=sel>0.5?'#fff':'#191f28';
  o3.querySelector('b').style.transform=`scale(${t<13.15?0:spring(t,13.15)})`;
  const shr=eio3(seg(t,13.35,13.7));
  o1.style.transform=`scale(${1-shr})`;o2.style.transform=`scale(${1-shr})`;
  const press3=t>=13.05&&t<13.4?1-0.03*Math.sin(Math.PI*seg(t,13.05,13.3)):1;
  // o3 -> phone (button expands into page)
  const ex=glide(seg(t,13.95,14.45));
  const ph=$('phone');
  const px=lerp(1080,1060,ex),py=lerp(oy[2],276,ex),pw=lerp(640,370,ex),phh=lerp(124,704,ex);
  o3.style.transform=`scale(${press3})`;
  if(t>=13.95){o3.style.left=px+'px';o3.style.top=py+'px';o3.style.width=pw+'px';o3.style.height=phh+'px';o3.style.borderRadius=lerp(32,60,ex)+'px';o3.style.background=`rgb(${Math.round(lerp(49,25,ex))},${Math.round(lerp(130,31,ex))},${Math.round(lerp(246,40,ex))})`;o3.querySelector('b').style.transform=`scale(${1-eio3(seg(t,13.95,14.1))})`;}
  ph.style.display=(t>=14.45&&t<16.45)?'block':'none';
  const toStat=glide(seg(t,16.0,16.45));
  ph.style.left=lerp(1060,1040,toStat)+'px';ph.style.top=lerp(276,300,toStat)+'px';ph.style.width=lerp(370,720,toStat)+'px';ph.style.height=lerp(704,470,toStat)+'px';ph.style.borderRadius=lerp(60,40,toStat)+'px';
  ph.style.background=`rgb(${Math.round(lerp(25,49,toStat))},${Math.round(lerp(31,130,toStat))},${Math.round(lerp(40,246,toStat))})`;
  const scrIn=eo4(seg(t,14.45,14.9));const scrOut=eio3(seg(t,15.95,16.15));
  const pimg=$('pimg');pimg.style.transform=`translateY(${((1-scrIn)*100+scrOut*-100).toFixed(1)}%)`;
  ph.querySelector('.scr').style.background=ph.style.background;
  ph.querySelector('.scr').style.display=t>=16.15?'none':'block';
  const ads=[['adA',1462,292,14.95],['adB',1690,410,15.2],['adC',1462,600,15.45]];
  ads.forEach(([id,x,y,t0])=>{const el=$(id);const back=glide(seg(t,15.8,16.1));const cxp=1060+185,cyp=276+352;el.style.left=lerp(x,cxp-100,back)+'px';el.style.top=lerp(y,cyp-125,back)+'px';const s=t<t0?0:spring(t,t0);el.style.transform=`scale(${(s*(1-back)).toFixed(4)}) rotate(${(lerp(-6,0,s)*(1-back)).toFixed(2)}deg)`;el.style.display=(t>=t0&&t<16.1)?'block':'none';});
  // stat card
  const st=$('stat');st.style.display=(t>=16.45&&t<18.2)?'block':'none';st.style.left='1040px';st.style.top='300px';st.style.width='720px';st.style.height='470px';
  const v=24.6*eo3(seg(tf,16.5,17.4));$('n246').textContent=v.toFixed(1);
  st.querySelectorAll('.sl,.ss').forEach((e,i)=>{const p=eexp(seg(t,16.6+i*0.1,17.0+i*0.1));e.firstElementChild.style.transform=`translateY(${((1-p)*115).toFixed(1)}%)`;});
  const vals=[61.10,57.40,63.04,64.96,63.67,79.31];
  st.querySelectorAll('#bars i').forEach((b,i)=>{const p=eo4(seg(t,16.6+i*0.07,17.1+i*0.07));b.style.height=(150*vals[i]/79.31)+'px';b.style.transform=`scaleY(${p.toFixed(4)})`;});
  // ---------- E
  reveal('E',t,17.7,1400,535,0.35);
  hideIfCovered('D',t,18.06);
  cam('camE',t,[[17.7,1.03,0,0],[20.3,1.0,0,0]]);
  rise('e1',t,18.1,20.35);rise('e2',t,18.25,20.4);
  if(!CH)CH=placeChips();
  for(let i=0;i<N_CLIENTS;i++){const el=$('cl'+i);const [x,y,w]=CH[i];const t0=18.55+i*0.11;const s=t<t0?0:spring(t,t0);const col=glide(seg(t,20.35,20.7));const cx=x+w/2,cy=y+48;const nx=lerp(cx,960,col),ny=lerp(cy,690,col);el.style.left=(nx-w/2)+'px';el.style.top=(ny-48)+'px';el.style.transform=`scale(${(s*(1-col*0.96)).toFixed(4)})`;}
  const ed=$('edot');ed.style.transform=`scale(${t<20.6?0:spring(t,20.6,3,0.8)})`;
  // ---------- FG
  reveal('FG',t,20.72,960,690,0.35);
  hideIfCovered('E',t,21.08);
  cam('camFG',t,[[20.72,1.0,0,0],[23.3,1.035,0,0]]);
  rise('f1',t,21.1,22.35);rise('f2',t,21.35,22.42);
  rise('f3',t,22.5,23.25,0.45);
  const w2=WM2.w,wx2=(W-w2-30)/2,wy2=300;
  const back2=eo3(seg(t,23.45,23.95));
  $('wm2').style.left=wx2+'px';$('wm2').style.top=wy2+'px';
  $('wm2Letters').style.transform=`scaleX(${(0.015+0.985*back2).toFixed(4)})`;
  $('wm2Letters').style.visibility=t>=23.45?'visible':'hidden';
  const d2=$('dot2');const dsz=30;const dpop=t<23.3?0:spring(t,23.3,2.6,0.7);
  d2.style.width=dsz+'px';d2.style.height=dsz+'px';d2.style.left=(wx2+w2+4)+'px';d2.style.top=(wy2+113)+'px';d2.style.transform=`scale(${dpop})`;
  rise('tg',t,24.0);
  const cta=$('cta');const cr=cta.getBoundingClientRect();cta.style.left=(960-cta.offsetWidth/2)+'px';cta.style.top='690px';cta.style.transform=`scale(${t<24.3?0:spring(t,24.3)})`;
  const qr=$('qr');qr.style.left='1560px';qr.style.top='700px';qr.style.transform=`scale(${t<24.55?0:spring(t,24.55)})`;
  cursorAt(t);
};
window.ready=async function(){await document.fonts.ready;for(const w of [300,500,600,700,800]){await document.fonts.load(w+' 100px P');}measure();window.seek(0);return [...document.fonts].filter(f=>f.status==='loaded').length;};
</script></body></html>
"""

html = (HTML.replace("%%WALLS%%", walls).replace("%%PATH%%", path_d).replace("%%PTS%%", json.dumps(PTS))
        .replace("%%NCL%%", str(len(CLIENTS))).replace("%%CHIPS%%", chips))
(here / "index.html").write_text(html, encoding="utf-8")
print("index.html", len(html), "maze points", len(PTS))
