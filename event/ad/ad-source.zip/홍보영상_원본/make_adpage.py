import html
import shutil
import zipfile
from pathlib import Path

import cv2

here = Path(__file__).parent
site = here.parent.parent / "site"
dst = site / "event" / "ad"
dst.mkdir(parents=True, exist_ok=True)
v = "20261022m"

shutil.copy(here / "ad.mp4", dst / "ad.mp4")
shutil.copy(here / "ad_silent.mp4", dst / "ad-silent.mp4")

SCENES = [
    (0.0, "브랜드", "honest family. 로고가 점으로 접히고, 점이 '사업성장연구소' 버튼이 됩니다."),
    (2.2, "고민", "매출 고민, 뭐부터 해야 할지 막막하신가요?"),
    (5.9, "막연함 → 다음 할 일", "미로를 빠져나가는 길이 그려집니다."),
    (8.45, "① 진단", "데이터로 원인을 찾고 — 뽀뽀뜨 첫 구매 고객 62%"),
    (12.0, "② 결정", "가장 크게 걸린 일 하나를 정하고 — 커서가 '다시 사게 만들기'를 고릅니다."),
    (14.0, "③ 실행", "고른 버튼이 휴대폰 화면이 되고, 가설별 광고 소재 3개가 나옵니다."),
    (16.0, "④ 확인", "숫자로 확인합니다 — 123타이어 리뉴얼 후 1년 매출 +24.6%"),
    (17.7, "함께해 온 곳", "다양한 규모의 업체와 협력해 왔습니다 — 11곳"),
    (20.7, "약속", "만들고 끝내지 않는 실행 파트너, 사업성장연구소"),
    (23.3, "마무리", "로고 · 무료 사업 분석 · QR"),
]
STILLS = [4.25, 11.5, 17.3, 25.5]


def frame_at(t, path):
    cap = cv2.VideoCapture(str(here / "ad_silent.mp4"))
    cap.set(cv2.CAP_PROP_POS_FRAMES, int(round(t * 60)))
    ok, fr = cap.read()
    cap.release()
    cv2.imwrite(str(path), fr, [cv2.IMWRITE_JPEG_QUALITY, 92] if str(path).endswith(".jpg") else [])


frame_at(25.5, dst / "poster.jpg")
for i, t in enumerate(STILLS, 1):
    frame_at(t, dst / f"still-{i}.png")

src_zip = dst / "ad-source.zip"
with zipfile.ZipFile(src_zip, "w", zipfile.ZIP_DEFLATED) as z:
    for name in ("index.html", "build_ad.py", "render.py", "music.py", "stills.py", "qa.py", "make_adpage.py"):
        z.write(here / name, f"홍보영상_원본/{name}")
    for f in (here / "assets").iterdir():
        z.write(f, f"홍보영상_원본/assets/{f.name}")
    for f in (here / "fonts").iterdir():
        z.write(f, f"홍보영상_원본/fonts/{f.name}")
    z.write(here / "music.wav", "홍보영상_원본/music.wav")
    z.writestr("홍보영상_원본/읽어보기.txt", "index.html 을 크롬으로 열고 콘솔에서 await ready(); seek(초) 로 원하는 장면을 볼 수 있습니다.\n다시 굽기: python build_ad.py → python render.py 6 → python music.py → ffmpeg 로 음악 합치기.\n글꼴 Pretendard 는 SIL Open Font License 1.1 입니다. 음악은 코드로 직접 합성한 것이라 저작권 걱정이 없습니다.\n")

btns = "".join(f'<button type="button" data-t="{t}"><b>{t:.1f}초</b>{html.escape(name)}</button>' for t, name, _ in SCENES)
rows = "".join(f"<tr><td>{t:.1f}초</td><td><b>{html.escape(name)}</b><br>{html.escape(desc)}</td></tr>" for t, name, desc in SCENES)
page = f"""<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="robots" content="noindex,nofollow">
<meta name="referrer" content="no-referrer">
<title>홍보 영상 — 어니스트패밀리 사업성장연구소</title>
<meta property="og:title" content="어니스트패밀리 사업성장연구소 홍보 영상 (26초)">
<meta property="og:image" content="https://honest-family.github.io/growth-lab-brochure/event/ad/poster.jpg?v={v}">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/variable/pretendardvariable-dynamic-subset.min.css">
<style>
:root{{--blue:#3182f6;--ink:#191f28;--sub:#4e5968;--muted:#6b7684;--line:#e5e8eb;--g1:#f2f4f6}}
*{{box-sizing:border-box}}
body{{margin:0;background:#fff;color:var(--ink);font-family:"Pretendard Variable",Pretendard,-apple-system,"Apple SD Gothic Neo","Malgun Gothic",sans-serif;line-height:1.6;word-break:keep-all}}
.wrap{{max-width:1000px;margin:0 auto;padding:0 18px}}
header{{padding:28px 0 10px}}
.back{{font-size:13px;font-weight:600;color:var(--muted);text-decoration:none}}
.k{{display:block;margin-top:12px;font-size:13px;font-weight:700;color:var(--blue)}}
h1{{margin:6px 0 8px;font-size:clamp(24px,6vw,36px);line-height:1.25;letter-spacing:-.035em}}
.lead{{margin:0 0 14px;color:var(--sub);font-size:15px}}
video{{display:block;width:100%;border-radius:14px;background:#000}}
.scenes{{display:flex;gap:8px;overflow-x:auto;padding:12px 0 6px}}
.scenes button{{flex:none;font:inherit;font-size:13px;font-weight:700;color:var(--ink);background:var(--g1);border:0;border-radius:12px;padding:8px 12px;cursor:pointer;text-align:left;line-height:1.35}}
.scenes button b{{display:block;font-size:12px;color:var(--blue)}}
.get{{display:flex;flex-wrap:wrap;gap:8px;margin:8px 0 18px}}
.get a{{display:inline-flex;flex-direction:column;font-size:15px;font-weight:800;text-decoration:none;padding:11px 15px;border-radius:13px;background:var(--blue);color:#fff;line-height:1.35}}
.get a small{{font-size:12px;font-weight:600;opacity:.85}}
.get a.dark{{background:var(--ink)}}
.get a.ghost{{background:#fff;color:var(--ink);border:1px solid var(--line)}}
h2{{font-size:19px;margin:22px 0 8px;letter-spacing:-.03em}}
table{{width:100%;border-collapse:collapse;font-size:14px}}
td{{border-top:1px solid var(--line);padding:9px 6px;vertical-align:top;color:var(--sub)}}
td:first-child{{width:64px;font-weight:800;color:var(--blue);white-space:nowrap}}
td b{{color:var(--ink)}}
footer{{padding:20px 0 40px;color:var(--muted);font-size:13px}}
</style>
</head>
<body>
<header class="wrap">
  <a class="back" href="../event.html?v={v}">← 행사 제출 자료로</a>
  <span class="k">이슈 #1286 · 홍보존 모니터 · 26초 · 1920×1080 · 60fps</span>
  <h1>어니스트패밀리 사업성장연구소<br>홍보 영상</h1>
  <p class="lead">우리가 무엇을 해 주는 회사인지(진단 → 결정 → 실행 → 확인)를 실제 화면과 실제 숫자로 보여 줍니다. 소리 없이 틀어도 내용이 전달되게 만들었습니다.</p>
</header>
<main class="wrap">
  <video id="v" src="ad/ad.mp4?v={v}" poster="ad/poster.jpg?v={v}" controls playsinline preload="metadata"></video>
  <div class="scenes">{btns}</div>
  <div class="get">
    <a href="ad/ad.mp4?v={v}" download="사업성장연구소_홍보영상_26초.mp4">영상 받기<small>음악 포함 · MP4</small></a>
    <a class="dark" href="ad/ad-silent.mp4?v={v}" download="사업성장연구소_홍보영상_26초_무음.mp4">무음 영상 받기<small>모니터 소리가 안 될 때</small></a>
    <a class="ghost" href="ad/ad-source.zip?v={v}" download="사업성장연구소_홍보영상_원본.zip">편집 원본<small>코드·글꼴·음악</small></a>
  </div>
  <h2>장면</h2>
  <table>{rows}</table>
</main>
<footer class="wrap"><p>숫자는 확인된 것만 넣었습니다(123타이어 쇼핑몰 주문 데이터 2026.10.20 기준 +24.6%, 뽀뽀뜨 데이터 진단 62%). 화면은 실제 뽀뽀뜨 페이지와 실제 광고 소재입니다. 음악은 코드로 직접 만든 것이라 공개해도 됩니다.</p></footer>
<script>
const v = document.getElementById('v');
document.querySelectorAll('.scenes button').forEach(b => b.addEventListener('click', () => {{ v.currentTime = parseFloat(b.dataset.t) + 0.01; v.play(); }}));
</script>
</body>
</html>
"""
(site / "event" / "ad.html").write_text(page, encoding="utf-8")
print("ad page ok", round(src_zip.stat().st_size / 1048576, 1), "MB source zip")
