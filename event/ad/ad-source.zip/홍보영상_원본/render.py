import subprocess
import sys
import time
from multiprocessing import Process
from pathlib import Path

here = Path(__file__).parent
FF = r"C:\Users\ssa41\AppData\Local\Programs\Python\Python312\Lib\site-packages\imageio_ffmpeg\binaries\ffmpeg-win-x86_64-v7.1.exe"
FPS, SUB, DUR = 60, 4, 26.0
N = int(round(FPS * DUR))
ARGS = ["--use-angle=d3d11", "--enable-gpu-rasterization", "--ignore-gpu-blocklist"]
segdir = here / "segs"


def worker(k, f0, f1):
    from playwright.sync_api import sync_playwright
    out = segdir / f"seg{k:02d}.mp4"
    vf = f"tmix=frames={SUB}:weights='{' '.join(['1'] * SUB)}',select='eq(mod(n\\,{SUB})\\,{SUB - 1})',setpts=N/{FPS}/TB"
    ff = subprocess.Popen([FF, "-y", "-loglevel", "error", "-f", "image2pipe", "-c:v", "png", "-framerate", str(FPS * SUB), "-i", "-",
                           "-vf", vf, "-r", str(FPS), "-c:v", "libx264", "-preset", "medium", "-crf", "15", "-pix_fmt", "yuv420p", str(out)],
                          stdin=subprocess.PIPE)
    with sync_playwright() as p:
        b = p.chromium.launch(args=ARGS)
        pg = b.new_page(viewport={"width": 1920, "height": 1080}, device_scale_factor=1)
        pg.goto((here / "index.html").as_uri())
        pg.evaluate("window.ready()")
        for f in range(f0, f1):
            tf = f / FPS
            for s in range(SUB):
                t = tf + (s + 0.5) / SUB * (0.5 / FPS)
                pg.evaluate("([t, tf]) => window.seek(t, tf)", [t, tf])
                ff.stdin.write(pg.screenshot(type="png"))
        b.close()
    ff.stdin.close()
    ff.wait()


if __name__ == "__main__":
    workers = int(sys.argv[1]) if len(sys.argv) > 1 else 6
    segdir.mkdir(exist_ok=True)
    for f in segdir.glob("*.mp4"):
        f.unlink()
    t0 = time.time()
    step = (N + workers - 1) // workers
    ps = []
    for k in range(workers):
        f0, f1 = k * step, min(N, (k + 1) * step)
        if f0 >= f1:
            continue
        pr = Process(target=worker, args=(k, f0, f1))
        pr.start()
        ps.append(pr)
    for pr in ps:
        pr.join()
    lst = here / "segs" / "list.txt"
    lst.write_text("".join(f"file '{p.as_posix()}'\n" for p in sorted(segdir.glob("seg*.mp4"))), encoding="utf-8")
    subprocess.run([FF, "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy", str(here / "ad_noaudio.mp4")], check=True)
    print("rendered", N, "frames in", round(time.time() - t0), "s")
