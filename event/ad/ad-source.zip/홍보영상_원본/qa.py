import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
cap = cv2.VideoCapture("ad.mp4")
frames = []
diffs = []
prev = None
i = 0
beat_imgs = []
while True:
    ok, fr = cap.read()
    if not ok:
        break
    small = cv2.resize(fr, (480, 270)).astype(np.int16)
    if prev is not None:
        diffs.append(float(np.abs(small - prev).mean()))
    prev = small
    t = i / 60
    if i % 30 == 15:
        beat_imgs.append((t, cv2.cvtColor(fr, cv2.COLOR_BGR2RGB)))
    i += 1
d = np.array(diffs)
spikes = []
for k in range(len(d)):
    a, b = max(0, k - 6), min(len(d), k + 7)
    nb = np.concatenate([d[a:k], d[k + 1:b]])
    med = np.median(nb) if len(nb) else 0
    if d[k] > 3 * max(med, 0.6) and d[k] > 4:
        spikes.append((round((k + 1) / 60, 3), round(d[k], 1), round(med, 2)))
print("frames", i, "spikes", spikes[:30])
cols = 6
w, h = 320, 180
rows = (len(beat_imgs) + cols - 1) // cols
sheet = Image.new("RGB", (cols * (w + 6) + 6, rows * (h + 26) + 6), (40, 40, 40))
dr = ImageDraw.Draw(sheet)
font = ImageFont.truetype(r"C:\Windows\Fonts\malgun.ttf", 18)
for j, (t, im) in enumerate(beat_imgs):
    r, c = divmod(j, cols)
    x, y = 6 + c * (w + 6), 6 + r * (h + 26)
    sheet.paste(Image.fromarray(im).resize((w, h)), (x, y))
    dr.text((x + 4, y + h + 2), f"{t:.2f}s", fill=(255, 255, 255), font=font)
sheet.save("beat_sheet.jpg", quality=85)
print("beat sheet", sheet.size)
