import subprocess
import wave
from pathlib import Path

import numpy as np

here = Path(__file__).parent
FF = r"C:\Users\ssa41\AppData\Local\Programs\Python\Python312\Lib\site-packages\imageio_ffmpeg\binaries\ffmpeg-win-x86_64-v7.1.exe"
SR, DUR, BEAT = 48000, 26.0, 0.5
n = int(SR * DUR)
L = np.zeros(n)
R = np.zeros(n)
rng = np.random.default_rng(7)


def add(sig, t0, gain=1.0, pan=0.0):
    i = int(t0 * SR)
    if i >= n:
        return
    s = sig[: n - i] * gain
    L[i:i + len(s)] += s * (1 - max(0, pan))
    R[i:i + len(s)] += s * (1 + min(0, pan))


def env(length, a, d):
    t = np.arange(int(length * SR)) / SR
    return np.minimum(1, t / max(a, 1e-4)) * np.exp(-t / d)


def kick():
    t = np.arange(int(0.32 * SR)) / SR
    f = 46 + 104 * np.exp(-t * 30)
    ph = 2 * np.pi * np.cumsum(f) / SR
    return np.sin(ph) * np.exp(-t * 11) * 0.9


def noise(length):
    return rng.standard_normal(int(length * SR))


def hat():
    x = np.diff(noise(0.06), prepend=0)
    return x * env(0.06, 0.001, 0.012) * 0.18


def clap():
    x = noise(0.22)
    x = x - np.convolve(x, np.ones(12) / 12, mode="same")
    return x * env(0.22, 0.002, 0.06) * 0.35


def tone(freq, length, a=0.005, d=0.3, harm=(1.0,), detune=0.0):
    t = np.arange(int(length * SR)) / SR
    s = sum(h * np.sin(2 * np.pi * freq * (k + 1) * t * (1 + detune * k)) for k, h in enumerate(harm))
    return s * env(length, a, d)


def pad_chord(freqs, length):
    t = np.arange(int(length * SR)) / SR
    s = np.zeros_like(t)
    for f in freqs:
        for k, h in enumerate((1.0, 0.35, 0.18, 0.08)):
            s += h * (np.sin(2 * np.pi * f * (k + 1) * t) + np.sin(2 * np.pi * f * (k + 1) * 1.003 * t))
    a = np.minimum(1, t / 0.25)
    r = np.minimum(1, (length - t) / 0.3)
    return s * a * np.clip(r, 0, 1) * 0.045


def pop():
    t = np.arange(int(0.09 * SR)) / SR
    f = 1250 * np.exp(-t * 9) + 520
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 38) * 0.28


def click():
    b = tone(2200, 0.03, 0.0005, 0.006) * 0.2
    x = noise(0.012) * np.exp(-np.arange(int(0.012 * SR)) / SR / 0.002) * 0.25
    b[:len(x)] += x
    return b


def whoosh(length=0.5):
    x = noise(length)
    t = np.arange(len(x)) / SR
    out = np.zeros_like(x)
    acc = 0.0
    for i in range(len(x)):
        k = 0.02 + 0.5 * (t[i] / length) ** 2
        acc += k * (x[i] - acc)
        out[i] = acc
    shape = np.sin(np.pi * np.clip(t / length, 0, 1)) ** 1.5
    return out * shape * 0.6


def bell(freq=1318.5):
    b = tone(freq, 1.8, 0.002, 0.55) * 0.22
    p2 = tone(freq * 2.76, 1.2, 0.002, 0.25) * 0.06
    p3 = tone(freq * 5.4, 0.6, 0.001, 0.12) * 0.03
    b[:len(p2)] += p2
    b[:len(p3)] += p3
    return b


C3, D3, E3, F3, G3, A3, B3 = 130.81, 146.83, 164.81, 174.61, 196.0, 220.0, 246.94
chords = [(C3, E3, G3, C3 * 2), (G3 / 2, B3 / 2, D3, G3), (A3 / 2, C3, E3, A3), (F3 / 2, A3 / 2, C3, F3)]
roots = [C3 / 2, G3 / 4 * 2 / 2 * 2, A3 / 4 * 2, F3 / 2]
for bar in range(13):
    t0 = bar * 4 * BEAT
    add(pad_chord(chords[bar % 4], 4 * BEAT + 0.3), t0, 1.0)
for b in range(52):
    t = b * BEAT
    if t >= 2.2 and t < 25.0:
        add(kick(), t, 0.85)
    if t >= 3.0 and t < 25.0:
        add(hat(), t + BEAT / 2, 0.9, pan=0.25)
        if b % 4 in (1, 3):
            add(clap(), t, 0.8)
    if t >= 6.0 and t < 25.0:
        root = roots[(b // 4) % 4]
        for e in (0, BEAT / 2):
            add(tone(root, 0.24, 0.004, 0.09, harm=(1.0, 0.25)), t + e, 0.32)
add(tone(523.25, 1.2, 0.005, 0.35, harm=(1.0, 0.3)), 0.0, 0.22)
add(tone(659.25, 1.0, 0.005, 0.3, harm=(1.0, 0.3)), 0.55, 0.18)
for t in (1.7, 2.75):
    add(whoosh(0.5), t, 0.5)
for t in (8.0, 17.25, 20.27):
    add(whoosh(0.5), t, 0.5)
for t in (2.05, 13.05):
    add(click(), t, 1.0)
for i in range(4):
    add(pop(), 9.05 + i * 0.12, 0.8, pan=-0.2 + i * 0.13)
for i in range(3):
    add(pop(), 12.3 + i * 0.08, 0.6)
for t in (14.95, 15.2, 15.45):
    add(pop(), t, 0.8)
for i in range(11):
    add(pop(), 18.55 + i * 0.11, 0.55, pan=-0.3 + 0.06 * i)
for t in (24.3, 24.55):
    add(pop(), t, 0.8)
add(bell(1046.5), 11.3, 1.0)
add(bell(1318.5), 17.4, 1.0)
add(bell(1567.98), 23.45, 0.9)
add(pad_chord(chords[0], 2.6), 24.0, 1.2)
mix = np.stack([L, R], axis=1)
mix /= max(1e-9, np.abs(mix).max()) / 0.9
fade = np.ones(n)
fade[-SR:] = np.linspace(1, 0, SR)
mix *= fade[:, None]
raw = here / "music_raw.wav"
with wave.open(str(raw), "wb") as w:
    w.setnchannels(2)
    w.setsampwidth(2)
    w.setframerate(SR)
    w.writeframes((mix * 32767).astype(np.int16).tobytes())
subprocess.run([FF, "-y", "-loglevel", "error", "-i", str(raw), "-af", "loudnorm=I=-14:TP=-1.5:LRA=11,alimiter=limit=0.76:level=false", "-ar", "48000", "-ac", "2", str(here / "music.wav")], check=True)
r = subprocess.run([FF, "-hide_banner", "-i", str(here / "music.wav"), "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True)
summary = r.stderr[r.stderr.rfind("Summary:"):]
print(summary.strip().replace("\n", " | ")[:400])
